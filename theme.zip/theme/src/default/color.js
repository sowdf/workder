/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:47:05
 * Copyright © Leedarson. All rights reserved.
 */

// base
export const colorBlack = '#000';
export const colorBlackLight = '#333';
export const colorWhite = '#fff';
export const colorGray = '#999';
export const colorGrayDark = '#666';

// primary
export const colorPrimary = '#1e50a0';
export const colorSuccess = '#65b3a2';
export const colorInfo = '#36a6f4';
export const colorWarn = '#f19f31';
export const colorDanger = '#c44a4a';

// background
export const bgColorDefault = '#EDEDED';
export const bgColorPrimary = '#F7F7F7';
export const bgColorActive = '#ECECEC';

// line
export const lineColorLight = 'rgba(0,0,0,.1)';
export const lineColorDark = 'rgba(0,0,0,.3)';

// text
export const textColorTitle = '#333';
export const textColorDesc = '#666';
export const textColorTips = '#999';
export const textColorWarn = colorWarn;

// mask
export const maskWhite = 'rgba(0,0,0,.05)';
export const maskGray = 'rgba(0,0,0,.1)';
export const maskBlack = 'rgba(0,0,0,.15)';
