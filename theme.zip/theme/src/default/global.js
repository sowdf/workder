/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:20:45
 * Copyright © Leedarson. All rights reserved.
 */

export const fontEN = '-apple-system-font,"Helvetica Neue"';
export const fontCN = '"PingFang SC","Hiragino Sans GB","Microsoft YaHei"';
export const fontDefault = `${fontEN},${fontCN}`;
