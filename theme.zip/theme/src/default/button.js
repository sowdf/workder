/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 10:27:53
 * Copyright © Leedarson. All rights reserved.
 */
import { colorWarn, maskGray } from './color';

const btnDisabledFontColor = 'rgba(0,0,0,.18)';
const btnDisabledBg = '#fafafa';
// base
export const btnWidth = '184px';
export const btnHeight = '40px';
export const btnFontSize = '17px';
export const btnBorderRadius = '4px';
export const btnPaddingY = '8px';
export const btnPaddingX = '24px';

// small
export const btnSmallHeight = '32px';
export const btnSmallFontSize = '16px';
export const btnSmallBorderRadius = '3px';
export const btnSmallPaddingY = '8px';
export const btnSmallPaddingX = '18px';

// default
export const btnDefaultBg = '#F2F2F2';
export const btnDefaultFontColor = '#06AE56';
export const btnDefaultActiveBg = '#D9D9D9';
export const btnDefaultActiveFontColor = '#06AE56';
export const btnDefaultDisabledFontColor = btnDisabledFontColor;
export const btnDefaultDisabledBg = btnDisabledBg;

// primary
export const btnPrimaryBg = '#07C160';
export const btnPrimaryFontColor = '#FFFFFF';
export const btnPrimaryActiveBg = '#06AD56';
export const btnPrimaryActiveFontColor = '#FFFFFF';
export const btnPrimaryDisabledFontColor = btnDisabledFontColor;
export const btnPrimaryDisabledBg = btnDisabledBg;

// warn
export const btnWarnBg = '#F2F2F2';
export const btnWarnFontColor = colorWarn;
export const btnWarnActiveBg = '#D9D9D9';
export const btnWarnActiveFontColor = colorWarn;
export const btnWarnDisabledBg = btnDisabledBg;
export const btnWarnDisabledFontColor = btnDisabledFontColor;

// plan && default
export const btnPlainDefaultBorderColor = 'rgba(53,53,53,1)';
export const btnPlainDefaultColor = 'rgba(53,53,53,1)';
export const btnPlainDefaultActiveBgColor = '#323232';

// plan && primary
export const btnPlainPrimaryBorderColor = 'rgba(26,173,25,1)';
export const btnPlainPrimaryColor = '#07C160';
export const btnPlainPrimaryActiveBgColor = maskGray;

// plan && warn
export const btnPlainWarnBorderColor = 'rgba(250,250,81,1)';
export const btnPlainWarnColor = '#F2F2F2';
export const btnPlainWarnActiveBgColor = maskGray;

// plan && disable
export const btnPlainDisableBorderColor = 'rgba(0, 0, 0, 0.2)';
export const btnPlainDisableColor = 'rgba(0, 0, 0, 0.2)';
