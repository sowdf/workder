# `@leedarson/component`

> TODO: description

## Usage

```
import component from '@leedarson/component';

// TODO: DEMONSTRATE API
```

import AntButton from 'antd-mobile/es/button';
@import 'antd-mobile/es/button/style/index.less';
