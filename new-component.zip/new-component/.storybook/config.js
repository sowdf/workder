import { configure, addParameters, addDecorator } from '@storybook/react';
import { create } from '@storybook/theming';
import { jsxDecorator } from 'storybook-addon-jsx';

addDecorator(jsxDecorator);

const basicTheme = create({
  brandTitle: 'IOT UI Mobile',
  brandUrl:
    'http://192.168.5.29:8090/iot-platform-frontend/iot-engine/tree/master/packages/component',
  brandImage: null,
});

addParameters({
  options: {
    panelPosition: 'right',
    theme: basicTheme,
  },
  viewport: {
    defaultViewport: 'iphone6',
  },
});

const req = require.context('../src/', true, /\.story\.jsx$/);
function loadStories() {
  req.keys().forEach(req);
}

configure(loadStories, module);
