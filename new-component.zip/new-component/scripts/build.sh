#!/bin/bash

echo -e "\n\033[32m ~~~ Mobile UI Component ~~~ Start compiling ~~~ \033[0m\n"; 

yarn run lint && yarn run test

# $? Results of the above execution
if [ $? = 0 ]; then
  rm -fr dist;
  bash scripts/build-js.sh;
  bash scripts/build-css.sh;
  echo -e "\n\033[32m ~~~ Mobile UI Component ~~~ End compiling ~~~ \033[0m\n"; 
else
  echo -e "\n\033[31m ~~~ Mobile UI Component ~~~ Code cant be verify, please check ~~~  \033[0m\n";
fi
