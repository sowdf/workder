#!/bin/bash

echo -e "\n\033[35m ~~~ Mobile UI Component ~~~ Start compiling JS files with babel ~~~ \033[0m\n";

SOURCE=src;
TARGET=dist;

# babel transform es6 into es5

## 1. commandjs
## export BABEL_ENV=development;
## npx babel src --out-dir dist/es5 --copy-files;

## 2. import/export
## export BABEL_ENV=production;
## npx babel src --out-dir dist/es6 --copy-files;

## 2. import/export
yarn run babel $SOURCE --out-dir $TARGET --copy-files;
# yarn run babel src --out-dir dist --copy-files --minified # 压缩代码

echo -e "\n\033[35m ~~~ Mobile UI Component ~~~ End compiling JS files with babel ~~~ \033[0m\n";

# 根据 BABEL_ENV 变量打包不同类型, commandjs 或者 import/export
# https://github.com/ElemeFE/element-react/blob/master/package.json
# https://github.com/ElemeFE/element-react/blob/master/.babelrc
# https://www.babeljs.cn/docs/babel-preset-env#modules
# https://www.babeljs.cn/docs/options#env
# http://guoyongfeng.github.io/my-gitbook/04/toc-customizing-babel-based-on-environment.html