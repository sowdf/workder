#/bin/bash

echo -e "\n\033[33m ~~~ Mobile UI Component ~~~ Start compiling CSS files with less ~~~ \033[0m\n";

DIRECTORY=dist;
# echo $DIRECTORY

LIST=$(find $DIRECTORY -name *.less);
# echo $LIST

for file in $LIST;
do
    FROM=$file
    # ${parameter/pattern/string}
    TO=${file/.less/.css}
    if [[ "$FROM" =~ 'themes' ]];then
      echo "$FROM --> Themes don't need to be packaged"
    else
      echo "$FROM --> $TO"
      yarn run lessc $FROM $TO --autoprefix --js
      # yarn run lessc $FROM $TO --autoprefix --clean-css # 压缩代码
    fi      
done

echo -e "\n\033[33m ~~~ Mobile UI Component ~~~ End compiling CSS files with less ~~~ \033[0m\n";
