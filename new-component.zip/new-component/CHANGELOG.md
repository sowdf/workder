# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.1.0-alpha.20](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.19...@leedarson/component@0.1.0-alpha.20) (2019-08-06)


### Features

* **SOFT-7020:** [[App] 界面细节优化] add ([882bbdb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/882bbdb))
* **SOFT-7020:** [[App] 界面细节优化] merge master ([d8451bc](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d8451bc))
* **SOFT-7376:** [[App] 修改bug] routine 代码提交 ([b0e0bbe](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b0e0bbe))
* **SOFT-7376:** [[App] 修改bug] 修改bug ([523873d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/523873d))
* **SOFT-7376:** [[App] 修改bug] 修改bug ([839e3d3](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/839e3d3))
* **SOFT-7376:** [[App] 修改bug] 修改Bug ([dde7df2](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/dde7df2))
* **SOFT-7376:** [[App] 修改bug] 修改Bug ([b685f61](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b685f61))
* **SOFT-7376:** [[App] 修改bug] 修改Bug ([ea361f0](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ea361f0))
* **SOFT-7376:** [[App] 修改bug] 新增about 页面 ([4f61fef](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4f61fef))
* **SOFT-7785:** [Room模块与House模块整理]  Room模块与House模块整理 ([f4c2a76](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f4c2a76))
* **SOFT-7785:** [Room模块与House模块整理] room模块与House模块整理 ([9cc3b6a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9cc3b6a))
* **SOFT-7785:** [Room模块与House模块整理] room模块与House模块整理 ([eedcab9](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/eedcab9))
* **SOFT-7785:** [Room模块与House模块整理] room模块与House模块整理 ([7eb7b56](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7eb7b56))





# [0.1.0-alpha.19](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.18...@leedarson/component@0.1.0-alpha.19) (2019-08-02)

**Note:** Version bump only for package @leedarson/component





# [0.1.0-alpha.18](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.17...@leedarson/component@0.1.0-alpha.18) (2019-08-02)


### Features

* **SOFT-7020:** [[App] 界面细节优化] fix text overflow ([3f48dd3](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/3f48dd3))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([990c9b4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/990c9b4))
* **SOFT-7376:** [[App] 修改bug] routine 代码提交 ([e320315](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e320315))
* **SOFT-7376:** [[App] 修改bug] scenes 代码提交 ([eac6896](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/eac6896))






# [0.1.0-alpha.17](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.16...@leedarson/component@0.1.0-alpha.17) (2019-08-01)


### Features

* **SOFT-1:** [test] test ([8758abf](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/8758abf))
* **SOFT-7020:** [[App] 界面细节优化] remove overflow ([9805343](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9805343))
* **SOFT-7020:** [[App] 界面细节优化] update ([ea8096b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ea8096b))
* **SOFT-7020:** [[App] 界面细节优化] update ([10ff57f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/10ff57f))
* **SOFT-7020:** [[App] 界面细节优化] update logic ([5c4b6eb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5c4b6eb))
* **SOFT-7020:** [[App] 界面细节优化] update wifi loading ([93636a6](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/93636a6))
* **SOFT-7020:** [[App] 界面细节优化] update wifi page ([247771e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/247771e))
* **SOFT-7286:** [MQTT联调]  MQTT联调 ([8eda8b7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/8eda8b7))
* **SOFT-7286:** [MQTT联调]  MQTT联调 ([15fd977](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/15fd977))
* **SOFT-7286:** [MQTT联调]  MQTT联调 ([a81a313](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a81a313))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([8c87db7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/8c87db7))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([d29424b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d29424b))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([76ed9d1](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/76ed9d1))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([c495eca](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/c495eca))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([c07fd7b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/c07fd7b))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([0c4405f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/0c4405f))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([26306d5](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/26306d5))
* **SOFT-7286:** [MQTT联调] mQTT联调 ([7b1fa55](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7b1fa55))
* **SOFT-7376:** [[App] 修改bug] bar-nav 定位修改 ([7770f42](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7770f42))
* **SOFT-7376:** [[App] 修改bug] 修改device icon ，提供占位图 ([2ea65a4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2ea65a4))
* **SOFT-7376:** [[App] 修改bug] 修改radio 颜色 ([7897220](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7897220))
* **SOFT-7376:** [[App] 修改bug] 修改storybook rem 配置 ([821fd76](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/821fd76))
* **SOFT-7376:** [[App] 修改bug] 修改名称加入房间 ([524d3b4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/524d3b4))
* **SOFT-7376:** [[App] 修改bug] 删除message 功能 ([1e62f17](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1e62f17))
* **SOFT-7376:** [[App] 修改bug] 完成button-group组件  ，修改分段器 样式 ([cc3bd46](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/cc3bd46))
* **SOFT-7376:** [[App] 修改bug] 完成label-select 组件，修改button demo inline 问题 ([c71746f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/c71746f))
* **SOFT-7376:** [[App] 修改bug] 完成设置页面 ([e8b5aaa](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e8b5aaa))
* **SOFT-7376:** [[App] 修改bug] 提交设置页面代码 ([98ed98d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/98ed98d))
* **SOFT-7376:** [[App] 修改bug] 设备名称编辑单独访问可以编辑 ([26ddac4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/26ddac4))





# [0.1.0-alpha.16](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.15...@leedarson/component@0.1.0-alpha.16) (2019-07-26)

**Note:** Version bump only for package @leedarson/component





# [0.1.0-alpha.15](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.14...@leedarson/component@0.1.0-alpha.15) (2019-07-26)

**Note:** Version bump only for package @leedarson/component






# [0.1.0-alpha.14](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.13...@leedarson/component@0.1.0-alpha.14) (2019-07-26)


### Features

* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] input Edit 修改onFocus ([9e35738](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9e35738))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 修改device icon 类型 ，添加所有的设备类型 ([b6adaf7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b6adaf7))
* **SOFT-7316:** [登录模块、个人中心重构] 登录模块、个人中心重构 ([852517a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/852517a))
* **SOFT-7316:** [登录模块、个人中心重构] 登录模块、个人中心重构 ([54dd0bd](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/54dd0bd))





# [0.1.0-alpha.13](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.12...@leedarson/component@0.1.0-alpha.13) (2019-07-26)


### Features

* **SOFT-7316:** [登录模块、个人中心重构] 登录模块、个人中心重构 ([1bbb375](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1bbb375))
* **SOFT-7316:** [登录模块、个人中心重构] 登录模块、个人中心重构 ([e14b1a6](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e14b1a6))
* **SOFT-7366:** [[App] 登录注册模块自测修改] update ([54af002](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/54af002))
* **SOFT-7366:** [[App] 登录注册模块自测修改] update ([147b6b0](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/147b6b0))





# [0.1.0-alpha.12](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.11...@leedarson/component@0.1.0-alpha.12) (2019-07-26)


### Features

* **SOFT-1:** [test] test ([0c98291](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/0c98291))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] scenes from 模块 ([90b48c8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/90b48c8))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 修改 device-icon 组件 ，修改 ([d2e98b7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d2e98b7))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 实现scenes 模块 ([ceee3a2](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ceee3a2))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 实现scenes模块 ([6e2d2ea](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6e2d2ea))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 实现设置模块 ([9bc9ffb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9bc9ffb))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 拉取更新 ([f2f8c2e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f2f8c2e))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 提交inputEdit 组件 ([d762441](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d762441))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 提交设置页面 ([cb5c67e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/cb5c67e))
* **SOFT-6350:** [[App] 实现 home模块下的设备设置模块] 设置模块 ([82c2687](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/82c2687))
* **SOFT-6382:** [Home页，allControl 功能]  Home页，allControl 功能 ([cd87381](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/cd87381))
* **SOFT-6382:** [Home页，allControl 功能] home页，allControl 功能 ([41e94f8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/41e94f8))
* **SOFT-6382:** [Home页，allControl 功能] home页，allControl 功能 ([3e00387](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/3e00387))
* **SOFT-7020:** [[App] 界面细节优化] add search ([ae36680](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ae36680))
* **SOFT-7020:** [[App] 界面细节优化] add search page ([38a634d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/38a634d))
* **SOFT-7020:** [[App] 界面细节优化] add sortable list ([4cad507](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4cad507))
* **SOFT-7020:** [[App] 界面细节优化] add wifi status page ([868e60b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/868e60b))
* **SOFT-7020:** [[App] 界面细节优化] update grid style ([d3d5c88](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d3d5c88))
* **SOFT-7020:** [[App] 界面细节优化] update room sort ([b33af54](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b33af54))
* **SOFT-7020:** [[App] 界面细节优化] update room tabs ([7a2ee0e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7a2ee0e))
* **SOFT-7020:** [[App] 界面细节优化] update route ([085444a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/085444a))
* **SOFT-7020:** [[App] 界面细节优化] 机型适配 ([2e55544](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2e55544))





# [0.1.0-alpha.11](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.10...@leedarson/component@0.1.0-alpha.11) (2019-07-23)


### Features

* **SOFT-6382:** [Home页，allControl 功能] home页，allControl 功能 ([88bc4ae](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/88bc4ae))
* **SOFT-6382:** [Home页，allControl 功能] home页，allControl 功能 ([f5746af](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f5746af))
* **SOFT-6382:** [Home页，allControl 功能] home页，allControl 功能 ([b3435eb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b3435eb))
* **SOFT-7020:** [[App] 界面细节优化] add loading ([fcb8d3e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/fcb8d3e))
* **SOFT-7020:** [[App] 界面细节优化] add skeleton ([27af292](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/27af292))
* **SOFT-7020:** [[App] 界面细节优化] update ([d3ea8b5](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d3ea8b5))
* **SOFT-7020:** [[App] 界面细节优化] update ([c1b90c7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/c1b90c7))
* **SOFT-7020:** [[App] 界面细节优化] update house ([a6b4271](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a6b4271))
* **SOFT-7020:** [[App] 界面细节优化] update logic ([886f247](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/886f247))
* **SOFT-7020:** [[App] 界面细节优化] update login ([6c11c43](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6c11c43))
* **SOFT-7020:** [[App] 界面细节优化] update product list grid style ([906a80f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/906a80f))





# [0.1.0-alpha.10](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.9...@leedarson/component@0.1.0-alpha.10) (2019-07-18)


### Features

* **SOFT-1:** [test] test ([cccb2a0](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/cccb2a0))





# [0.1.0-alpha.9](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.8...@leedarson/component@0.1.0-alpha.9) (2019-07-18)

**Note:** Version bump only for package @leedarson/component





# [0.1.0-alpha.8](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.7...@leedarson/component@0.1.0-alpha.8) (2019-07-18)


### Features

* **SOFT-6382:** [Home页，allControl 功能] 添加page组件demo ([b602d1a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b602d1a))
* **SOFT-6428:** [[App] 实现设备控制面板] add all control ([8f19cab](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/8f19cab))





# [0.1.0-alpha.7](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.6...@leedarson/component@0.1.0-alpha.7) (2019-07-17)


### Features

* **SOFT-3522:** [【E、Tab4 Me-个人主页说明】 Lighting app] add avatar ([b3abf66](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b3abf66))
* **SOFT-3522:** [【E、Tab4 Me-个人主页说明】 Lighting app] 修改api 地址为 httpServer ([17b9bfb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/17b9bfb))
* **SOFT-3522:** [【E、Tab4 Me-个人主页说明】 Lighting app] 修改个人中心 ([bab0f52](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/bab0f52))
* **SOFT-3522:** [【E、Tab4 Me-个人主页说明】 Lighting app] 合并master ([9bab5c8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9bab5c8))
* **SOFT-3522:** [【E、Tab4 Me-个人主页说明】 Lighting app] 添加empty组件 ([162f589](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/162f589))
* **SOFT-3522:** [【E、Tab4 Me-个人主页说明】 Lighting app] 添加上传图片模块 ([2d2a8f5](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2d2a8f5))
* **SOFT-6382:** [Home页，allControl 功能] home ([5800576](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5800576))





# [0.1.0-alpha.6](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.5...@leedarson/component@0.1.0-alpha.6) (2019-07-16)


### Features

* **SOFT-6206:** [[App] 实现设备列表逻辑] add device logic ([5767a9f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5767a9f))
* **SOFT-6206:** [[App] 实现设备列表逻辑] update ([014a245](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/014a245))
* **SOFT-6206:** [[App] 实现设备列表逻辑] update rem ([83a3ccb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/83a3ccb))
* **SOFT-6211:** [[App] 组件单位替换测2倍图] 删除log修改布局 组件 ([ed73c25](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ed73c25))
* **SOFT-6211:** [[App] 组件单位替换测2倍图] 组件单位替换 ([d157ca2](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d157ca2))





# [0.1.0-alpha.5](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.4...@leedarson/component@0.1.0-alpha.5) (2019-07-15)

**Note:** Version bump only for package @leedarson/component





# [0.1.0-alpha.4](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.3...@leedarson/component@0.1.0-alpha.4) (2019-07-15)


### Features

* **SOFT-6136:** [[App] 实现 相关组件 组件] 实现 home 下相关的组件 ([e6605f6](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e6605f6))
* **SOFT-6136:** [[App] 实现 相关组件 组件] 实现home 相关组件 ([887499f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/887499f))
* **SOFT-6136:** [[App] 实现 相关组件 组件] 实现wifi loading组件 ([ed602d5](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ed602d5))
* **SOFT-6159:** [[App] 优化家和房间业务处理逻辑] add room logic ([55b8c49](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/55b8c49))





# [0.1.0-alpha.3](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.2...@leedarson/component@0.1.0-alpha.3) (2019-07-11)


### Features

* **SOFT-1:** [test] test ([e5b5e60](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e5b5e60))





# [0.1.0-alpha.2](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.1...@leedarson/component@0.1.0-alpha.2) (2019-07-11)

**Note:** Version bump only for package @leedarson/component





# [0.1.0-alpha.1](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@leedarson/component@0.1.0-alpha.0...@leedarson/component@0.1.0-alpha.1) (2019-07-11)


### Features

* **SOFT-1:** [test] test ([f37298c](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f37298c))
* **SOFT-1:** [test] test ([abaeb4f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/abaeb4f))
* **SOFT-1:** [test] test ([126f937](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/126f937))
* **SOFT-5802:** [[App] 实现设备列表] add room & home logic ([7478484](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7478484))





# 0.1.0-alpha.0 (2019-07-11)


### Features

* **SOFT-1:** [add docz] docz ([712d686](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/712d686))
* **SOFT-1:** [test] test ([2c27ceb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2c27ceb))
* **SOFT-1:** [test] test ([95b2587](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/95b2587))
* **SOFT-1:** [test] test ([689a446](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/689a446))
* **SOFT-24:** [init mobile ui component] init ([2c14d4f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2c14d4f))
* **SOFT-26:** [test] test ([acb22ee](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/acb22ee))
* **SOFT-26:** [test] test ([f323153](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f323153))
* **SOFT-26:** [test] test ([6485647](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6485647))
* **SOFT-26:** [test] test ([bea73e8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/bea73e8))
* **SOFT-3569:** [[App] 实现Button组件] input实现组件 ([2fa0def](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2fa0def))
* **SOFT-3569:** [[App] 实现Button组件] update button style & demo ([9475093](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9475093))
* **SOFT-3569:** [[App] 实现Button组件] 修改readme inline 边距问题 ([4da9776](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4da9776))
* **SOFT-3569:** [[App] 实现Button组件] 修改按钮间距，调整small 按钮 文字居中问题 ([203f2c7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/203f2c7))
* **SOFT-36:** [add container] add ([4851c5f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4851c5f))
* **SOFT-3643:** [[App] 实现Input组件] 修改input 去掉边框 ([187857b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/187857b))
* **SOFT-3643:** [[App] 实现Input组件] 修改readme，添加例子 ([2f428db](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2f428db))
* **SOFT-3643:** [[App] 实现Input组件] 修改变量名,修改图标改为icon组件 ([7c9f995](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7c9f995))
* **SOFT-3643:** [[App] 实现Input组件] 修改变量名,修改图标改为icon组件 ([6cd0b6e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6cd0b6e))
* **SOFT-3643:** [[App] 实现Input组件] 实现input组件，修改index.less ([0089adf](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/0089adf))
* **SOFT-3644:** [[App] 实现登录页面] add login logic ([16c6e3e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/16c6e3e))
* **SOFT-3644:** [[App] 实现登录页面] add register & resetpassword logic ([de5daa5](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/de5daa5))
* **SOFT-3644:** [[App] 实现登录页面] review ([b8261ef](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b8261ef))
* **SOFT-3644:** [[App] 实现登录页面] review ([a49f77f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a49f77f))
* **SOFT-3644:** [[App] 实现登录页面] update component ([5c43cc1](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5c43cc1))
* **SOFT-3644:** [[App] 实现登录页面] update flex layout & typography  component ([511e894](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/511e894))
* **SOFT-3644:** [[App] 实现登录页面] update login page ([4c71202](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4c71202))
* **SOFT-3645:** [[App] 实现Icon组件] add icon component ([b1667e1](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b1667e1))
* **SOFT-3645:** [[App] 实现Icon组件] add iconfont config ([b842381](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b842381))
* **SOFT-3645:** [[App] 实现Icon组件] update icon api & demo style ([124f429](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/124f429))
* **SOFT-3645:** [[App] 实现Icon组件] update icon propTypes ([926556b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/926556b))
* **SOFT-3646:** [[App] 实现Model组件] add base modal component ([41f885b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/41f885b))
* **SOFT-3646:** [[App] 实现Model组件] add compose modal & update demo ([1429510](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1429510))
* **SOFT-3646:** [[App] 实现Model组件] more friendly ([77be793](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/77be793))
* **SOFT-3646:** [[App] 实现Model组件] remove compose ([8d0154e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/8d0154e))
* **SOFT-3646:** [[App] 实现Model组件] remove prefixCls & update footer api ([29e134a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/29e134a))
* **SOFT-3646:** [[App] 实现Model组件] update class demo ([18a6d66](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/18a6d66))
* **SOFT-3668:** [【IOT-Moblie 组件库】List 组件开发] edit list less style ([5f8cc6b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5f8cc6b))
* **SOFT-3668:** [【IOT-Moblie 组件库】List 组件开发] list 组件开发 ([a661bd7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a661bd7))
* **SOFT-3668:** [【IOT-Moblie 组件库】List 组件开发] 修改list 下边线问题,去除点击动画 ([ed145ae](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ed145ae))
* **SOFT-3792:** [[App] 优化组件库文档] add storybook ([903944d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/903944d))
* **SOFT-3792:** [[App] 优化组件库文档] add storybook doc ([ff4c221](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ff4c221))
* **SOFT-4062:** [[App] 实现 NavBar 组件] add NavBar component ([820693d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/820693d))
* **SOFT-4075:** [[App] 实现 Toast 组件] add toast ([5cf1648](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5cf1648))
* **SOFT-4075:** [[App] 实现 Toast 组件] update less var ([f7addcb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f7addcb))
* **SOFT-4081:** [[App] 实现 Typography 组件] [App] 实现 Typography 组件 ([18b8a6b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/18b8a6b))
* **SOFT-4081:** [[App] 实现 Typography 组件] add less style ([1993f8f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1993f8f))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改readme ([619b1b4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/619b1b4))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([7cf265d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7cf265d))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([641a150](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/641a150))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([c7bf606](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/c7bf606))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([d14b455](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d14b455))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改标题字号 ([91b680d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/91b680d))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改示例 ([a2739ae](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a2739ae))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] add inactive color ([47359a4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/47359a4))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] add TabBar ([9c6a403](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9c6a403))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] remove useless props ([4c34903](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4c34903))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] rename ([2cb7459](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2cb7459))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] update storybook cli ([ab4d50b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ab4d50b))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] add button size api ([949fd59](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/949fd59))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] change color name ([3b1537a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/3b1537a))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] remove flex overflow ([a29ff83](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a29ff83))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update component ([9a0a985](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9a0a985))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update doc ([e52c090](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e52c090))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update doc ([9d86ced](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9d86ced))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update flex doc ([27380ca](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/27380ca))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update list & input ([6d579e6](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6d579e6))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update modal doc ([24b8063](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/24b8063))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update overflow & icon default prop ([565795a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/565795a))
* **SOFT-4184:** [[App] 实现 Flex、 WingBlank、WhiteSpace 组件] add layout component ([4cd06cf](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4cd06cf))
* **SOFT-4192:** [[App] 实现 Switch CheckBox 组件] 实现 Switch CheckBox 组件 ([65332a2](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/65332a2))
* **SOFT-4268:** [[App] 实现verfiy account, fotget password,create home 页面] import React from 'react'; ([7950e6c](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7950e6c))
* **SOFT-4651:** [[App] 实现 PopUP、PopDown 组件] add pop component ([d34ba54](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d34ba54))
* **SOFT-5654:** [[App] 实现 Create Home 逻辑] add home page ([743e369](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/743e369))
* **SOFT-5661:** [[App] 实现调色板组件] add default color ([196847e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/196847e))
* **SOFT-5661:** [[App] 实现调色板组件] add palette ([34ee84c](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/34ee84c))
* **SOFT-5739:** [[App] 实现 Slider、色温 组件] add palette click handler ([4ea6293](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4ea6293))
* **SOFT-5739:** [[App] 实现 Slider、色温 组件] add slider ([443341d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/443341d))
* **SOFT-5802:** [[App] 实现设备列表] add device tabs ([a25e01d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a25e01d))
* **SOFT-5802:** [[App] 实现设备列表] add grid & update device ([f15ea19](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f15ea19))
* **SOFT-5802:** [[App] 实现设备列表] add room tabs ([ffca35f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ffca35f))
* **SOFT-5802:** [[App] 实现设备列表] update ([59d32e4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/59d32e4))
* **SOFT-60:** [UPDATE] uPDATE ([9c9024b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9c9024b))
* **SOFT-61:** [add i18N] update ([5af59f0](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5af59f0))
* **SOFT-62:** [pick component] pick ([137d3f8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/137d3f8))
* **SOFT-71:** [use src directory] publish version use src ([455273a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/455273a))
* **SOFT-80:** [merge conflict] merge ([1e003d8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1e003d8))





# [0.1.0-alpha.20](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.19...@packages/component@0.1.0-alpha.20) (2019-07-09)


### Features

* **SOFT-5802:** [[App] 实现设备列表] add device tabs ([a25e01d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a25e01d))
* **SOFT-5802:** [[App] 实现设备列表] add grid & update device ([f15ea19](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f15ea19))
* **SOFT-5802:** [[App] 实现设备列表] add room tabs ([ffca35f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ffca35f))
* **SOFT-5802:** [[App] 实现设备列表] update ([59d32e4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/59d32e4))





# [0.1.0-alpha.19](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.18...@packages/component@0.1.0-alpha.19) (2019-07-08)


### Features

* **SOFT-5739:** [[App] 实现 Slider、色温 组件] add palette click handler ([4ea6293](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4ea6293))
* **SOFT-5739:** [[App] 实现 Slider、色温 组件] add slider ([443341d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/443341d))





# [0.1.0-alpha.18](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.17...@packages/component@0.1.0-alpha.18) (2019-07-05)

**Note:** Version bump only for package @packages/component





# [0.1.0-alpha.17](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.16...@packages/component@0.1.0-alpha.17) (2019-07-05)


### Features

* **SOFT-1:** [test] test ([689a446](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/689a446))
* **SOFT-3644:** [[App] 实现登录页面] add login logic ([16c6e3e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/16c6e3e))
* **SOFT-3644:** [[App] 实现登录页面] add register & resetpassword logic ([de5daa5](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/de5daa5))
* **SOFT-3644:** [[App] 实现登录页面] review ([b8261ef](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b8261ef))
* **SOFT-3644:** [[App] 实现登录页面] review ([a49f77f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a49f77f))
* **SOFT-3644:** [[App] 实现登录页面] update component ([5c43cc1](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5c43cc1))
* **SOFT-3644:** [[App] 实现登录页面] update flex layout & typography  component ([511e894](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/511e894))
* **SOFT-3644:** [[App] 实现登录页面] update login page ([4c71202](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4c71202))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update flex doc ([27380ca](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/27380ca))
* **SOFT-5654:** [[App] 实现 Create Home 逻辑] add home page ([743e369](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/743e369))
* **SOFT-5661:** [[App] 实现调色板组件] add default color ([196847e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/196847e))
* **SOFT-5661:** [[App] 实现调色板组件] add palette ([34ee84c](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/34ee84c))





# [0.1.0-alpha.16](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.15...@packages/component@0.1.0-alpha.16) (2019-07-01)


### Features

* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update doc ([e52c090](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/e52c090))
* **SOFT-4268:** [[App] 实现verfiy account, fotget password,create home 页面] import React from 'react'; ([7950e6c](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7950e6c))
* **SOFT-4651:** [[App] 实现 PopUP、PopDown 组件] add pop component ([d34ba54](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d34ba54))
* **SOFT-80:** [merge conflict] merge ([1e003d8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1e003d8))





# [0.1.0-alpha.15](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.14...@packages/component@0.1.0-alpha.15) (2019-06-27)


### Features

* **SOFT-4171:** [[App] 完善登录页相关组件及文档] change color name ([3b1537a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/3b1537a))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] remove flex overflow ([a29ff83](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a29ff83))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update component ([9a0a985](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9a0a985))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update doc ([9d86ced](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9d86ced))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update list & input ([6d579e6](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6d579e6))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update overflow & icon default prop ([565795a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/565795a))
* **SOFT-4192:** [[App] 实现 Switch CheckBox 组件] 实现 Switch CheckBox 组件 ([65332a2](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/65332a2))





# [0.1.0-alpha.14](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.13...@packages/component@0.1.0-alpha.14) (2019-06-27)


### Features

* **SOFT-26:** [test] test ([acb22ee](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/acb22ee))
* **SOFT-3668:** [【IOT-Moblie 组件库】List 组件开发] edit list less style ([5f8cc6b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5f8cc6b))
* **SOFT-3668:** [【IOT-Moblie 组件库】List 组件开发] list 组件开发 ([a661bd7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a661bd7))
* **SOFT-3668:** [【IOT-Moblie 组件库】List 组件开发] 修改list 下边线问题,去除点击动画 ([ed145ae](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ed145ae))





# [0.1.0-alpha.13](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.12...@packages/component@0.1.0-alpha.13) (2019-06-26)


### Features

* **SOFT-71:** [use src directory] publish version use src ([455273a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/455273a))





# [0.1.0-alpha.12](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.11...@packages/component@0.1.0-alpha.12) (2019-06-25)

**Note:** Version bump only for package @packages/component





# [0.1.0-alpha.11](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.10...@packages/component@0.1.0-alpha.11) (2019-06-25)


### Features

* **SOFT-26:** [test] test ([f323153](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f323153))





# [0.1.0-alpha.10](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.9...@packages/component@0.1.0-alpha.10) (2019-06-25)

**Note:** Version bump only for package @packages/component





# [0.1.0-alpha.9](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.8...@packages/component@0.1.0-alpha.9) (2019-06-25)


### Features

* **SOFT-26:** [test] test ([6485647](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6485647))





# [0.1.0-alpha.8](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.7...@packages/component@0.1.0-alpha.8) (2019-06-25)


### Features

* **SOFT-62:** [pick component] pick ([137d3f8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/137d3f8))





# [0.1.0-alpha.7](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.6...@packages/component@0.1.0-alpha.7) (2019-06-25)


### Features

* **SOFT-4171:** [[App] 完善登录页相关组件及文档] add button size api ([949fd59](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/949fd59))
* **SOFT-4171:** [[App] 完善登录页相关组件及文档] update modal doc ([24b8063](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/24b8063))
* **SOFT-4184:** [[App] 实现 Flex、 WingBlank、WhiteSpace 组件] add layout component ([4cd06cf](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4cd06cf))
* **SOFT-60:** [UPDATE] uPDATE ([9c9024b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9c9024b))
* **SOFT-61:** [add i18N] update ([5af59f0](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5af59f0))





# [0.1.0-alpha.6](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.5...@packages/component@0.1.0-alpha.6) (2019-06-25)

**Note:** Version bump only for package @packages/component





# [0.1.0-alpha.5](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.4...@packages/component@0.1.0-alpha.5) (2019-06-25)


### Features

* **SOFT-3569:** [[App] 实现Button组件] input实现组件 ([2fa0def](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2fa0def))
* **SOFT-3569:** [[App] 实现Button组件] update button style & demo ([9475093](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9475093))
* **SOFT-3569:** [[App] 实现Button组件] 修改readme inline 边距问题 ([4da9776](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4da9776))
* **SOFT-3569:** [[App] 实现Button组件] 修改按钮间距，调整small 按钮 文字居中问题 ([203f2c7](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/203f2c7))
* **SOFT-3643:** [[App] 实现Input组件] 修改input 去掉边框 ([187857b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/187857b))
* **SOFT-3643:** [[App] 实现Input组件] 修改readme，添加例子 ([2f428db](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2f428db))
* **SOFT-3643:** [[App] 实现Input组件] 修改变量名,修改图标改为icon组件 ([7c9f995](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7c9f995))
* **SOFT-3643:** [[App] 实现Input组件] 修改变量名,修改图标改为icon组件 ([6cd0b6e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/6cd0b6e))
* **SOFT-3643:** [[App] 实现Input组件] 实现input组件，修改index.less ([0089adf](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/0089adf))
* **SOFT-3646:** [[App] 实现Model组件] add base modal component ([41f885b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/41f885b))
* **SOFT-3646:** [[App] 实现Model组件] add compose modal & update demo ([1429510](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1429510))
* **SOFT-3646:** [[App] 实现Model组件] more friendly ([77be793](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/77be793))
* **SOFT-3646:** [[App] 实现Model组件] remove compose ([8d0154e](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/8d0154e))
* **SOFT-3646:** [[App] 实现Model组件] remove prefixCls & update footer api ([29e134a](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/29e134a))
* **SOFT-3646:** [[App] 实现Model组件] update class demo ([18a6d66](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/18a6d66))
* **SOFT-4062:** [[App] 实现 NavBar 组件] add NavBar component ([820693d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/820693d))
* **SOFT-4075:** [[App] 实现 Toast 组件] add toast ([5cf1648](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/5cf1648))
* **SOFT-4075:** [[App] 实现 Toast 组件] update less var ([f7addcb](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/f7addcb))
* **SOFT-4081:** [[App] 实现 Typography 组件] [App] 实现 Typography 组件 ([18b8a6b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/18b8a6b))
* **SOFT-4081:** [[App] 实现 Typography 组件] add less style ([1993f8f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/1993f8f))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改readme ([619b1b4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/619b1b4))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([7cf265d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/7cf265d))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([641a150](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/641a150))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([c7bf606](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/c7bf606))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改文档,修改示例界面 ([d14b455](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/d14b455))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改标题字号 ([91b680d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/91b680d))
* **SOFT-4081:** [[App] 实现 Typography 组件] 修改示例 ([a2739ae](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/a2739ae))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] add inactive color ([47359a4](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/47359a4))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] add TabBar ([9c6a403](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/9c6a403))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] remove useless props ([4c34903](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4c34903))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] rename ([2cb7459](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2cb7459))
* **SOFT-4083:** [[App] 实现 TabBar、Tabs、Badge 组件] update storybook cli ([ab4d50b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ab4d50b))





# [0.1.0-alpha.4](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.3...@packages/component@0.1.0-alpha.4) (2019-06-19)


### Features

* **SOFT-3645:** [[App] 实现Icon组件] add icon component ([b1667e1](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b1667e1))
* **SOFT-3645:** [[App] 实现Icon组件] add iconfont config ([b842381](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/b842381))
* **SOFT-3645:** [[App] 实现Icon组件] update icon api & demo style ([124f429](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/124f429))
* **SOFT-3645:** [[App] 实现Icon组件] update icon propTypes ([926556b](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/926556b))





# [0.1.0-alpha.3](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.2...@packages/component@0.1.0-alpha.3) (2019-06-18)


### Features

* **SOFT-3792:** [[App] 优化组件库文档] add storybook ([903944d](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/903944d))
* **SOFT-3792:** [[App] 优化组件库文档] add storybook doc ([ff4c221](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/ff4c221))





# [0.1.0-alpha.2](https://192.168.5.29/iot-platform-frontend/iot-engine/compare/@packages/component@0.1.0-alpha.1...@packages/component@0.1.0-alpha.2) (2019-06-17)

**Note:** Version bump only for package @packages/component





# 0.1.0-alpha.1 (2019-06-14)


### Features

* **SOFT-1:** [add docz] docz ([712d686](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/712d686))
* **SOFT-24:** [init mobile ui component] init ([2c14d4f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2c14d4f))
* **SOFT-26:** [test] test ([bea73e8](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/bea73e8))
* **SOFT-36:** [add container] add ([4851c5f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4851c5f))





# 0.1.0-alpha.0 (2019-06-14)


### Features

* **SOFT-1:** [add docz] docz ([712d686](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/712d686))
* **SOFT-24:** [init mobile ui component] init ([2c14d4f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/2c14d4f))
* **SOFT-36:** [add container] add ([4851c5f](https://192.168.5.29/iot-platform-frontend/iot-engine/commits/4851c5f))
