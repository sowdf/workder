import WhiteSpace from './WhiteSpace';

export default WhiteSpace;
