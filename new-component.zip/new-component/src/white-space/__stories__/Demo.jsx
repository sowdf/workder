import React from 'react';
import WhiteSpace from '..';
import '../index.less';

const PlaceHolder = () => <div className="placeholder">Block</div>;

const WhiteSpaceExample = () => (
  <div>
    <WhiteSpace mul={1} />
    <PlaceHolder />

    <WhiteSpace mul={2} />
    <PlaceHolder />

    <WhiteSpace mul={3} />
    <PlaceHolder />

    <WhiteSpace mul={4} />
    <PlaceHolder />
  </div>
);

export default WhiteSpaceExample;
