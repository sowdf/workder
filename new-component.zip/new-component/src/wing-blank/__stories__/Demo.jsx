import React from 'react';
import WingBlank from '..';
import WhiteSpace from '../../white-space';
import '../index.less';

const PlaceHolder = () => <div className="placeholder">Block</div>;

const WingBlankExample = () => (
  <div style={{ padding: '15px 0' }}>
    <WingBlank>
      <PlaceHolder />
    </WingBlank>

    <WhiteSpace mul={2} />
    <WingBlank mul={2}>
      <PlaceHolder />
    </WingBlank>

    <WhiteSpace mul={2} />
    <WingBlank mul={3}>
      <PlaceHolder />
    </WingBlank>
  </div>
);

export default WingBlankExample;
