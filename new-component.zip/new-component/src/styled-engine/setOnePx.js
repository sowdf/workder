/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-14 17:29:44
 * Copyright © Leedarson. All rights reserved.
 */

import { css } from 'styled-components';

const setTopLine = (borderColor = '#C7C7C7') => css`
  content: ' ';
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  height: 1px;
  border-bottom: 1px solid ${borderColor};
  color: ${borderColor};
  transform-origin: 0 100%;
  transform: scaleY(0.5);
`;

const setBottomLine = (borderColor = '#C7C7C7') => css`
  content: ' ';
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  height: 1px;
  border-top: 1px solid ${borderColor};
  color: ${borderColor};
  transform-origin: 0 0;
  transform: scaleY(0.5);
`;

const setLeftLine = (borderColor = '#C7C7C7') => css`
  content: ' ';
  position: absolute;
  left: 0;
  bottom: 0;
  top: 0;
  width: 1px;
  border-left: 1px solid ${borderColor};
  color: ${borderColor};
  transform-origin: 0 0;
  transform: scaleY(0.5);
`;

const setRightLine = (borderColor = '#C7C7C7') => css`
  content: ' ';
  position: absolute;
  right: 0;
  bottom: 0;
  top: 0;
  width: 1px;
  border-right: 1px solid ${borderColor};
  color: ${borderColor};
  transform-origin: 100% 0;
  transform: scaleY(0.5);
`;

export { setTopLine, setBottomLine, setLeftLine, setRightLine };
