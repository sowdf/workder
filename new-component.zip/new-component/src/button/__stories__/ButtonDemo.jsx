/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 19:17:01
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import styled, { ThemeProvider } from 'styled-components';
import { WhiteSpace, WingBlank } from '../..';
import Button from '../index';

const Demo = () => (
  <WingBlank mul={3}>
    <WhiteSpace mul={2} />
    <h3>类型 （type）</h3>
    <WhiteSpace mul={2} />

    <h4>contained (默认)</h4>
    <Button color="default">contained-default</Button>
    <WhiteSpace mul={2} />

    <Button>contained-primary</Button>
    <WhiteSpace mul={2} />

    <Button color="danger">contained-danger</Button>
    <WhiteSpace mul={2} />

    <h4>outlined</h4>
    <Button type="outlined" color="default">
      outlined-default
    </Button>
    <WhiteSpace mul={2} />

    <WhiteSpace mul={2} />

    <Button color="danger" type="outlined">
      outlined-danger
    </Button>
    <Button color="textPrimary" type="outlined">
      outlined-textPrimary
    </Button>
    <WhiteSpace mul={2} />

    <h4>ghost</h4>

    <div style={{ background: '#909294', padding: '10px' }}>
      <Button type="ghost">ghost</Button>
    </div>

    <WhiteSpace mul={2} />

    <h3>inline</h3>
    <WhiteSpace mul={2} />

    <Button inline>inline-default</Button>
    <WhiteSpace mul={2} />

    <Button inline>inline-primary</Button>

    <WhiteSpace mul={2} />

    <h3>尺寸</h3>
    <WhiteSpace mul={2} />

    <Button inline>inline-lg</Button>
    <WhiteSpace mul={2} />

    <Button inline size="sm">
      inline-sm
    </Button>

    <WhiteSpace mul={2} />

    <h3>状态 / loading</h3>

    <WhiteSpace mul={2} />

    <Button loading>primary-loading</Button>

    <WhiteSpace mul={2} />

    <Button color="default" loading>
      defautl-loading
    </Button>

    <WhiteSpace mul={2} />

    <Button type="outlined" color="default" loading>
      outlined-default
    </Button>

    <WhiteSpace mul={2} />

    <h3>状态 / disabled</h3>

    <WhiteSpace mul={2} />

    <Button color="default" disabled>
      contained-default
    </Button>

    <WhiteSpace mul={2} />

    <Button color="primary" disabled>
      contained-primary
    </Button>
    <WhiteSpace mul={2} />

    <Button color="danger" disabled>
      contained-danger
    </Button>
    <WhiteSpace mul={2} />

    <Button type="outlined" color="default" disabled>
      outlined-default
    </Button>
    <WhiteSpace mul={2} />

    <Button color="danger" type="outlined" disabled>
      outlined-danger
    </Button>
    <WhiteSpace mul={2} />

    <div style={{ background: '#909294', padding: '10px' }}>
      <Button type="ghost" disabled>
        ghost
      </Button>
    </div>

    <WhiteSpace mul={2} />

    <Button inline disabled>
      inline-default
    </Button>
    <WhiteSpace mul={2} />

    <Button inline color="primary" disabled>
      inline-primary
    </Button>
    <WhiteSpace mul={2} />
  </WingBlank>
);

export default Demo;
