# Button

点击后会触发一个操作

## API

| 属性     | 说明                                                                                  | 类型              | 默认值    |
| -------- | ------------------------------------------------------------------------------------- | ----------------- | --------- |
| type     | 按钮类型，可选值为`contained`/`outlined`/`inline`/`ghost`                             | string            | contained |
| color    | 按钮颜色，可选值为`default`/`primary`/`danger`  `textPrimary` 在Outlined 下特有的颜色 | string            | primary   |
| size     | 按钮大小，可选值为`lg`/`sm`                                                           | string            | lg        |
| disabled | 设置禁用                                                                              | boolean           | false     |
| onClick  | 点击按钮的点击回调函数                                                                | (e: Object): void | 无        |
| inline   | 是否设置为行内按钮                                                                    | boolean           | false     |
| loading  | 设置按钮载入状态 (暂未支持 type 为 inline 的 loading)                                 | boolean           | false     |
| icon     | 设置图标                                                                              | ReactElement      |           |
