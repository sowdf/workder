import React from 'react';
import PropTypes from 'prop-types';
import StyledButton from './StyleButton';

const Button = props => {
  const { children, type, size, block, disabled, loading, onClick } = props;

  return (
    <StyledButton type={type} size={size} block={block} disabled={disabled} loading={loading} onClick={onClick}>
      {children}
    </StyledButton>
  );
};

Button.defaultProps = {
  type: 'default',
  size: 'large',
  block: false,
  disabled: false,
  loading: false,
  onClick: () => {},
};

Button.propTypes = {
  type: PropTypes.oneOfType(['default', 'primary', 'warn']),
  size: PropTypes.oneOfType(['small', 'large']),
  block: PropTypes.bool,
  disabled: PropTypes.bool,
  loading: PropTypes.bool,
  onClick: PropTypes.func,
  children: PropTypes.node.isRequired,
};

export default Button;
