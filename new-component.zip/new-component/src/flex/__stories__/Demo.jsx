/*
 * @Author: lixinxiang@leedarson.com
 * @Date: 2019-06-25 13:58:34
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { WhiteSpace } from 'antd-mobile';
import 'antd-mobile/lib/white-space/style/css';
import './demo.less';
import '../index.less';

import Flex from '..';

const PlaceHolder = ({ className, ...rest }) => (
  <div className={`${className} placeholder`} {...rest}>
    Block
  </div>
);

PlaceHolder.defaultProps = {
  className: '',
};

PlaceHolder.propTypes = {
  className: PropTypes.string,
};

const Demo = () => (
  <div className="flex-container">
    <h3>基础</h3>

    <Flex direction="row">
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
    </Flex>
    <WhiteSpace size="lg" />
    <Flex direction="row">
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
    </Flex>
    <WhiteSpace size="lg" />
    <Flex direction="row">
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
      <Flex.Item>
        <PlaceHolder />
      </Flex.Item>
    </Flex>
    <WhiteSpace size="lg" />

    <h3>Wrap</h3>

    <Flex direction="row" wrap="wrap">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
    </Flex>
    <WhiteSpace size="lg" />

    <h3>水平对齐 （ justify ）</h3>

    <h4>center</h4>
    <Flex direction="row" justify="center">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
    </Flex>

    <h4>end</h4>
    <WhiteSpace />
    <Flex direction="row" justify="end">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
    </Flex>

    <h4>between</h4>
    <WhiteSpace />
    <Flex direction="row" justify="between">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline" />
    </Flex>

    <h3>垂直对齐 （ align ）</h3>

    <h4>start</h4>
    <WhiteSpace />
    <Flex direction="row" align="start">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline small" />
      <PlaceHolder className="inline" />
    </Flex>

    <h4>end</h4>
    <WhiteSpace />
    <Flex direction="row" align="end">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline small" />
      <PlaceHolder className="inline" />
    </Flex>

    <h4>baseline</h4>
    <WhiteSpace />
    <Flex direction="row" align="baseline">
      <PlaceHolder className="inline" />
      <PlaceHolder className="inline small" />
      <PlaceHolder className="inline" />
    </Flex>
  </div>
);
export default Demo;
