/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 11:02:59
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';

const StyledFlexItem = styled.div`
  flex: 1;
`;

const FlexItem = ({ children }) => {
  return <StyledFlexItem>{children}</StyledFlexItem>;
};

FlexItem.propTypes = {
  children: PropTypes.node.isRequired,
};

export default FlexItem;
