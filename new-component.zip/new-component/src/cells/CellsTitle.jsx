import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';

// padding-left: @weuiCellGapH;
// padding-right: @weuiCellGapH;
// color: @weuiTextColorDesc;
// font-size: @weuiCellTipsFontSize;
const StyledCellTitle = styled.div`
  margin-top: 16px;
  margin-bottom: 3px;
  padding-left: 16px;
  padding-right: 16px;
  line-height: 1.4;
`;

const CellTitle = props => {
  const { children } = props;

  return <StyledCellTitle>{children}</StyledCellTitle>;
};

CellTitle.propTypes = {
  children: PropTypes.node.isRequired,
};

export default CellTitle;
