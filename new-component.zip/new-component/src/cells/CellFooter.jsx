import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';

const StyledCellHeader = styled.div`
  text-align: right;
  color: @weuiTextColorDesc;
`;

const CellFooter = props => {
  const { children } = props;

  return <StyledCellHeader>{children}</StyledCellHeader>;
};

CellFooter.propTypes = {
  children: PropTypes.node.isRequired,
};

export default CellFooter;
