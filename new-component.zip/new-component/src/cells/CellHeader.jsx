import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';

const StyledCellHeader = styled.div``;

const CellHeader = props => {
  const { children } = props;

  return <StyledCellHeader>{children}</StyledCellHeader>;
};

CellHeader.propTypes = {
  children: PropTypes.node.isRequired,
};

export default CellHeader;
