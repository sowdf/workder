import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';
import { setTopLine, setBottomLine } from '../styled-engine/setOnePx';

// margin-top: @weuiCellsMarginTop;
// background-color: @weuiCellBg;
// line-height: @weuiCellLineHeight;
// font-size: @weuiCellFontSize;
// .setTopLine(@weuiCellBorderColor);
const StyledCells = styled.div`
  margin-top: 8px;
  background-color: #fff;
  line-height: ${`${(56 - 2 * 17) / 24}px`};
  font-size: 17px;
  overflow: hidden;

  /* one px */
  position: relative;
  &:before {
    ${setTopLine()}
    z-index: 2;
  }
  &:after {
    ${setBottomLine()}
    z-index: 2;
  }
`;

const Cells = props => {
  const { children } = props;

  return <StyledCells>{children}</StyledCells>;
};

Cells.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Cells;
