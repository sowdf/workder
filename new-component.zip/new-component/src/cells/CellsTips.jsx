import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';

// color: @weuiTextColorDesc;
// padding-left: @weuiCellGapH;
// padding-right: @weuiCellGapH;
const StyledCellTips = styled.div`
  margin-top: 8px;
`;

const CellTips = props => {
  const { children } = props;

  return <StyledCellTips>{children}</StyledCellTips>;
};

CellTips.propTypes = {
  children: PropTypes.node.isRequired,
};

export default CellTips;
