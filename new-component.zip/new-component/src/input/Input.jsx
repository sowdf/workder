/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-15 17:57:16
 * Copyright © Leedarson. All rights reserved.
 */

import React from 'react';
import PropTypes from 'prop-types';
import StyledInput from './style';

const Input = props => {
  const { type, readonly, disabled, placeholder, onChange, onBlur, onFocus, ...rests } = props;

  return (
    <StyledInput
      type={type}
      readonly={readonly}
      disabled={disabled}
      placeholder={placeholder}
      onChange={onChange}
      onBlur={onBlur}
      onFocus={onFocus}
      {...rests}
    />
  );
};

Input.defaultProps = {
  type: 'text',
  readonly: false,
  disabled: false,
  defaultValue: null,
  value: null,
  placeholder: null,
  onChange: () => {},
  onBlur: () => {},
  onFocus: () => {},
};

Input.propTypes = {
  type: PropTypes.oneOfType(['text', 'phone', 'password', 'number']),
  readonly: PropTypes.bool,
  disabled: PropTypes.bool,
  defaultValue: PropTypes.oneOf([PropTypes.string, PropTypes.number]),
  value: PropTypes.oneOf([PropTypes.string, PropTypes.number]),
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  onBlur: PropTypes.func,
  onFocus: PropTypes.func,
};

export default Input;
