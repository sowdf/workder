import { styled } from 'styled-components';

const StyleInput = styled.input`
  width: 100%;
  border: 0;
  outline: 0;
  -webkit-appearance: none;
  background-color: transparent;
  font-size: inherit;
  color: inherit;
  height: ${props => props.cellLineHeight};
  line-height: ${props => props.cellLineHeight};
  &::-webkit-outer-spin-button,
  &::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;
export default StyleInput;
