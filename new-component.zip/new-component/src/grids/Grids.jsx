import React from 'react';
import PropTypes from 'prop-types';
import { styled } from 'styled-components';

const StyledGrid = styled.div`
  position: relative;
  overflow: hidden;
`;

const StyledGridItem = styled.div`
  position: relative;
  float: left;
  width: ${props => (100 / props.baseCols) * props.cols}%;
  box-sizing: border-box;
`;

const Grid = ({ children, cols }) => {
  return (
    <StyledGrid>
      {React.Children.map(children, child => {
        const { cols: childrenCols } = child.props;
        return (
          <StyledGridItem baseCols={cols} cols={childrenCols}>
            {child.children}
          </StyledGridItem>
        );
      })}
    </StyledGrid>
  );
};

Grid.defaultProps = {
  cols: 3,
};

Grid.propTypes = {
  children: PropTypes.node.isRequired,
  cols: PropTypes.number,
};

export default Grid;
