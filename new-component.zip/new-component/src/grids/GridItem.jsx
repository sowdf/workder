import React from 'react';
import PropTypes from 'prop-types';

const GridItem = () => {};

GridItem.defaultProps = {
  cols: 1,
};
GridItem.propTypes = {
  cols: PropTypes.number,
  children: PropTypes.node.isRequired,
};

export default GridItem;
